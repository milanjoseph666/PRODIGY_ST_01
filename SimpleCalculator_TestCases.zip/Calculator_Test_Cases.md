
# 🧪 Test Cases for Simple Calculator Application

This document contains detailed test cases for a simple calculator app that performs addition, subtraction, multiplication, and division.

---

## ✅ Valid Input Test Cases

### TC001 - Add Two Positive Integers
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `5 + 3`
  2. Press `=`
- **Expected Result**: Output should be `8`.

### TC002 - Subtract Negative from Positive
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `10 - (-2)`
  2. Press `=`
- **Expected Result**: Output should be `12`.

### TC003 - Multiply Decimals
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `2.5 * 4.2`
  2. Press `=`
- **Expected Result**: Output should be `10.5`.

### TC004 - Division with Decimal Result
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `7 / 2`
  2. Press `=`
- **Expected Result**: Output should be `3.5`.

### TC005 - Complex BODMAS
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `(2 + 3) * 4`
  2. Press `=`
- **Expected Result**: Output should be `20`.

---

## ❌ Invalid Input Test Cases

### TC006 - Division by Zero
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `9 / 0`
  2. Press `=`
- **Expected Result**: Error or message like `Cannot divide by zero`.

### TC007 - Non-numeric Characters
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `abc + 5`
  2. Press `=`
- **Expected Result**: Error or input should be rejected.

### TC008 - Multiple Operators Without Operands
- **Preconditions**: Calculator app is open.
- **Test Steps**:
  1. Input `++--`
- **Expected Result**: Error or invalid expression alert.

---

**Note**: Ensure calculator follows order of operations and handles floating-point precision.
